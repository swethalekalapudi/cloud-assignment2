


steps:

1. collect the ECG data from kaggle datasets.
2. Stream it on Cloud.
3. Open GCP Console and go to AI Platform section.
4. Under AI Platform, choose AI Notebooks and create a new instance of notebook.
5. Select python3 and other configurations of the notebook instance and start the instance.
6. Using the data that we have, analyse the data and make visualisations and build ML Models.
7. After performing necessary actions in the GCP platform, terminate the instance and delete the resources.

